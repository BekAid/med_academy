from django.contrib import admin
from drugstore.models import Customer, Tag, ProductForMedicine, Order

admin.site.register(Customer)
admin.site.register(Tag)
admin.site.register(ProductForMedicine)
admin.site.register(Order)
# Register your models here.
